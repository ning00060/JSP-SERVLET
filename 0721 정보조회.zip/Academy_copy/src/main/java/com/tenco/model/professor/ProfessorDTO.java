package com.tenco.model.professor;

public class ProfessorDTO {

}
