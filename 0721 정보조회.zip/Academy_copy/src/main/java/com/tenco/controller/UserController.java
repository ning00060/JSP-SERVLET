package com.tenco.controller;

import java.io.IOException;

import com.tenco.Repo.student.StudentRepositoryImpl;
import com.tenco.Repo.user.UserRepositoryImpl;
import com.tenco.model.student.StudentDTO;
import com.tenco.model.user.UserDTO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/user/*")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserRepositoryImpl userRepositoryImpl;
	private StudentRepositoryImpl studentRepositoryImpl;

	public UserController() {
		super();

	}

	@Override
	public void init() throws ServletException {
		userRepositoryImpl = new UserRepositoryImpl();
		studentRepositoryImpl = new StudentRepositoryImpl();
	}

	// 아이디 찾기, 비밀번호 찾기 sendredirect
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = request.getPathInfo();

		switch (action) {
		case "/findId":
			break;

		case "/findPw":
			break;
			
		case "/My":
			// TODO - 홈페이지 MY 페이지 클릭 시 이동 하는 창
			System.out.println("/doGet /My");
			 request.getRequestDispatcher("/My_page.jsp").forward(request, response);
			break;
		
		case "/My-data":
			// TODO - MY 페이지 클릭 시 버튼 클릭 리스트 화면으로 이동
			System.out.println("/doGet /My-data");
			handleMydata(request, response);
			request.getRequestDispatcher("/My_page2.jsp").forward(request, response);
			break;

		default:
			break;
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = request.getPathInfo();

		switch (action) {

		case "/login":
			// TODO - 로그 삭제 예정
			System.out.println("/login 됨");
			handleLogin(request, response);
			break;
			
		case "/My-data":
			// 내 정보 조회
			// TODO - 삭제예정
			System.out.println("/ doPost My-data 까지 진입?");
			handleMydata(request, response);
			break;

		default:
			break;
		}

	}



	private void handleLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// userLogin return 값은 1로 리턴! || Impl 수정 필요
		// if (userRepositoryImpl.userLogin("", "") == 1) {
		// 로그인 성공
		
		String usename = request.getParameter("username");
		String password = request.getParameter("password");
		
		UserDTO a = userRepositoryImpl.userLogin(usename, password);
		
		if(a != null) {
			System.out.println(a);
			// permission-level 확인 1=학생, 2=교수, 3= 관리직
			HttpSession session = request.getSession();
			// TODO - Principal 값 넘어오는지 확인
			session.setAttribute("principal", a);
			// TODO - 정상적동 하는지 확인 - 삭제예정
			System.out.println("jsp넘겨짐");
			// TODO - 메인 홈페이지로 이동한다.
			 request.getRequestDispatcher("/main_body.jsp").forward(request, response);
		
	} else {
		// TODO 로그인 실패시 다시 로그인 창으로 이동
		request.getRequestDispatcher("/index.jsp").forward(request, response);
		System.out.println("로그인 실패");
		}
	
	}
	
	/**
	 * My 페이지 클릭 시 
	 * @param request
	 * @param response
	 * @throws IOException 
	 * @throws ServletException 
	 */
	private void handleMydata(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String a = request.getParameter("number");
		System.out.println(a);
		StudentDTO student = studentRepositoryImpl.search(a);
		request.setAttribute("student", student);
		request.getRequestDispatcher("/My_page2.jsp").forward(request, response);
	}
	
}
